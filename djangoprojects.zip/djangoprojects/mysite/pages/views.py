from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404
from django.utils import timezone
from django.core.paginator import Paginator
from .models import Product

# Test məhsul məlumatları (modeldən asılı deyil)
products_list = [
    {"id": i,
     "name": f"Məhsul {i}",
     "short_description": f"Bu {i}-ci məhsulun qısa təsviri",
     "description": f"Bu {i}-ci məhsul haqqında ətraflı məlumat",
     "price": i * 10}
    for i in range(1, 101)  # 1-dən 100-ə qədər məhsul
]


# Sadə səhifələr
def home(request):
    return HttpResponse("Ev səhifəsinə xoş gəlmisiniz!")

def about(request):
    return HttpResponse("Bu, Haqqında Səhifəsidir.")

def contact(request):
    return HttpResponse("Bizimlə əlaqə saxlayın: contact@example.com.")

# Task səhifələri
def index(request):
    return render(request, 'pages/index.html')

def index2(request):
    context = {
        'title': 'Xoş Gəlmisiniz',
        'message': 'Django layihənizə xoş gəldiniz!',
    }
    return render(request, 'pages/index2.html', context)

def index3(request):
    context = {'is_logged_in': True}
    return render(request, 'pages/index3.html', context)

def index4(request):
    context = {'menu_items': ['Ana Səhifə', 'Haqqında', 'Əlaqə']}
    return render(request, 'pages/index4.html', context)

def index5(request):
    users = [
        {'name': 'Elvin', 'role': 'Admin'},
        {'name': 'Leyla', 'role': 'Redaktor'},
        {'name': 'Kamran', 'role': 'Moderator'},
    ]
    return render(request, 'pages/index5.html', {'users': users})

def index6(request):
    current_date = timezone.now()
    return render(request, 'pages/index6.html', {'current_date': current_date})

# Xəbərlər siyahısı (pagination)
news_list = [
    {"title": f"Xəbər {i}", "description": f"Bu {i}-ci xəbər haqqında qısa məlumat.", "date": f"2025-11-{(i%30)+1:02d}"}
    for i in range(1, 31)
]

def news_list_view(request):
    per_page = int(request.GET.get("per_page", 5))
    page = int(request.GET.get("page", 1))

    total_items = len(news_list)
    total_pages = (total_items + per_page - 1) // per_page

    if page < 1: page = 1
    if page > total_pages: page = total_pages

    start = (page - 1) * per_page
    end = start + per_page
    current_items = news_list[start:end]

    context = {
        "items": current_items,
        "current_page": page,
        "total_pages": total_pages,
        "previous_page": page - 1 if page > 1 else None,
        "next_page": page + 1 if page < total_pages else None,
        "per_page": per_page,
        "page_range": range(1, total_pages + 1),
    }
    return render(request, "pages/index7.html", context)

# Məhsullar siyahısı

def home_(request):
    # hər səhifədə neçə məhsul göstərilsin
    per_page = int(request.GET.get("per_page", 6))
    # mövcud səhifə nömrəsi
    page = int(request.GET.get("page", 1))

    total_items = len(products_list)
    total_pages = (total_items + per_page - 1) // per_page

    if page < 1:
        page = 1
    if page > total_pages:
        page = total_pages

    start = (page - 1) * per_page
    end = start + per_page
    current_items = products_list[start:end]

    context = {
        "products": current_items,
        "current_page": page,
        "total_pages": total_pages,
        "previous_page": page - 1 if page > 1 else None,
        "next_page": page + 1 if page < total_pages else None,
        "per_page": per_page,
        "page_range": range(1, total_pages + 1),
    }
    return render(request, "pages/home.html", context)


def main(request, product_id):
    product = next((p for p in products_list if p["id"] == product_id), None)
    if not product:
        return HttpResponse("Məhsul tapılmadı", status=404)

    return render(request, "pages/main.html", {"product": product})


def abouttt(request):
    return render(request, 'pages/about.html')
