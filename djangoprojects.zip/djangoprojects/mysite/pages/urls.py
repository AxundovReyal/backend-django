from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),               
    path('about/', views.about, name='about'),        
    path('contact/', views.contact, name='contact'),  
   
    path('task1/', views.index, name='task1'),
    path('task2/', views.index2, name='task2'),
    path('task3/', views.index3, name='task3'),
    path('task4/', views.index4, name='task4'),
    path('task5/', views.index5, name='task5'),
    path('task6/', views.index6, name='task6'),
    path('task7/', views.news_list_view, name='news_list'),

    
    path('products/', views.home_, name='products'),
    path('product/<int:product_id>/', views.main, name='main'),

   
    path('abouttt/', views.abouttt, name='abouttt'),
]
