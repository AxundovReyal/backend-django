from django.http import HttpResponseNotFound
def error404(request,exception):
    return HttpResponseNotFound('SEHIFE TAPILMADI')
