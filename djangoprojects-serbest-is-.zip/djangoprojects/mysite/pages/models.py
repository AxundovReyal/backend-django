from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone

class Car(models.Model):
    """Maşın modeli"""
    FUEL_CHOICES = [
        ('benzin', 'Benzin'),
        ('dizel', 'Dizel'),
        ('elektrik', 'Elektrik'),
        ('hibrid', 'Hibrid'),
    ]
    
    TRANSMISSION_CHOICES = [
        ('mexaniki', 'Mexaniki'),
        ('avtomat', 'Avtomat'),
    ]
    
    STATUS_CHOICES = [
        ('musait', 'Müsait'),
        ('icarede', 'İcarədə'),
        ('temirde', 'Təmirdə'),
    ]
    
    marka = models.CharField(max_length=100, verbose_name="Marka")
    model = models.CharField(max_length=100, verbose_name="Model")
    il = models.IntegerField(verbose_name="İstehsal ili", validators=[MinValueValidator(1990)])
    reng = models.CharField(max_length=50, verbose_name="Rəng")
    yakit_novu = models.CharField(max_length=20, choices=FUEL_CHOICES, verbose_name="Yanacaq növü")
    suretler_qutusu = models.CharField(max_length=20, choices=TRANSMISSION_CHOICES, verbose_name="Sürətlər qutusu")
    oturacaq_sayi = models.IntegerField(default=5, verbose_name="Oturacaq sayı")
    gunluk_qiymet = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Gündəlik qiymət (AZN)")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='musait', verbose_name="Status")
    sekil = models.ImageField(upload_to='cars/', blank=True, null=True, verbose_name="Şəkil")
    qeyd = models.TextField(blank=True, null=True, verbose_name="Qeyd")
    yaradilma_tarixi = models.DateTimeField(auto_now_add=True, verbose_name="Yaradılma tarixi")
    
    class Meta:
        verbose_name = "Maşın"
        verbose_name_plural = "Maşınlar"
        ordering = ['-yaradilma_tarixi']
    
    def __str__(self):
        return f"{self.marka} {self.model} ({self.il})"
    
    @property
    def is_available(self):
        """Maşın müsaitdirmi?"""
        return self.status == 'musait'


class Customer(models.Model):
    """Müştəri modeli"""
    ad = models.CharField(max_length=100, verbose_name="Ad")
    soyad = models.CharField(max_length=100, verbose_name="Soyad")
    telefon = models.CharField(max_length=20, verbose_name="Telefon")
    email = models.EmailField(verbose_name="Email", unique=True)
    vesiqe_nomresi = models.CharField(max_length=50, verbose_name="Vəsiqə nömrəsi")
    suruculuk_vesiqesi = models.CharField(max_length=50, verbose_name="Sürücülük vəsiqəsi")
    unvan = models.TextField(verbose_name="Ünvan")
    qeydiyyat_tarixi = models.DateTimeField(auto_now_add=True, verbose_name="Qeydiyyat tarixi")
    
    class Meta:
        verbose_name = "Müştəri"
        verbose_name_plural = "Müştərilər"
        ordering = ['-qeydiyyat_tarixi']
    
    def __str__(self):
        return f"{self.ad} {self.soyad}"


class Rental(models.Model):
    """İcarə modeli"""
    STATUS_CHOICES = [
        ('aktiv', 'Aktiv'),
        ('bitib', 'Bitib'),
        ('legv_olunub', 'Ləğv olunub'),
    ]
    
    masin = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='rentals', verbose_name="Maşın")
    musteri = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='rentals', verbose_name="Müştəri")
    baslama_tarixi = models.DateTimeField(verbose_name="Başlama tarixi")
    bitis_tarixi = models.DateTimeField(verbose_name="Bitmə tarixi")
    gunluk_qiymet = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Gündəlik qiymət")
    umumi_qiymet = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Ümumi qiymət")
    depozit = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Depozit")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='aktiv', verbose_name="Status")
    qeyd = models.TextField(blank=True, null=True, verbose_name="Qeyd")
    yaradilma_tarixi = models.DateTimeField(auto_now_add=True, verbose_name="Yaradılma tarixi")
    
    class Meta:
        verbose_name = "İcarə"
        verbose_name_plural = "İcarələr"
        ordering = ['-yaradilma_tarixi']
    
    def __str__(self):
        return f"{self.musteri} - {self.masin} ({self.baslama_tarixi.date()})"
    
    def save(self, *args, **kwargs):
        """Ümumi qiyməti avtomatik hesabla"""
        if self.baslama_tarixi and self.bitis_tarixi:
            gun_sayi = (self.bitis_tarixi - self.baslama_tarixi).days
            if gun_sayi < 1:
                gun_sayi = 1
            self.umumi_qiymet = self.gunluk_qiymet * gun_sayi
        super().save(*args, **kwargs)
    
    @property
    def gun_sayi(self):
        """İcarə müddəti (gün)"""
        if self.baslama_tarixi and self.bitis_tarixi:
            days = (self.bitis_tarixi - self.baslama_tarixi).days
            return days if days > 0 else 1
        return 0