from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
from datetime import timedelta
from .models import Car, Customer, Rental

# Konstant dəyərlər
CARS_PER_PAGE = 9
RENTALS_PER_PAGE = 10


def car_list(request):
    """Bütün maşınların siyahısı (filtrasiya və pagination ilə)"""
    cars = Car.objects.all()  # əvvəlcə hamısını götür
    
    # Status filteri (istəsən saxla)
    status = request.GET.get('status')
    if status:
        cars = cars.filter(status=status)
    
    # Axtarış
    search_query = request.GET.get('search', '')
    if search_query:
        cars = cars.filter(
            Q(marka__icontains=search_query) | 
            Q(model__icontains=search_query)
        )
    
    # Filtrlər
    yakit = request.GET.get('yakit')
    if yakit:
        cars = cars.filter(yakit_novu=yakit)
    
    suretler = request.GET.get('suretler')
    if suretler:
        cars = cars.filter(suretler_qutusu=suretler)
    
    # Qiymət sıralaması
    sort = request.GET.get('sort', '')
    if sort == 'price_asc':
        cars = cars.order_by('gunluk_qiymet')
    elif sort == 'price_desc':
        cars = cars.order_by('-gunluk_qiymet')
    
    # Pagination
    paginator = Paginator(cars, CARS_PER_PAGE)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'selected_yakit': yakit,
        'selected_suretler': suretler,
        'sort': sort,
        'selected_status': status,
    }
    return render(request, 'pages/car_list.html', context)


def car_detail(request, car_id):
    """Maşın detalları"""
    car = get_object_or_404(Car, id=car_id)
    
    context = {
        'car': car,
        'min_date': (timezone.now() + timedelta(days=1)).strftime('%Y-%m-%d'),
    }
    return render(request, 'pages/car_detail.html', context)


def rent_car(request, car_id):
    """Maşın icarəsi"""
    car = get_object_or_404(Car, id=car_id)
    
    if not car.is_available:
        messages.error(request, 'Bu maşın hazırda müsait deyil.')
        return redirect('pages:car_detail', car_id=car_id)
    
    if request.method == 'POST':
        # Müştəri məlumatları
        ad = request.POST.get('ad')
        soyad = request.POST.get('soyad')
        telefon = request.POST.get('telefon')
        email = request.POST.get('email')
        vesiqe = request.POST.get('vesiqe')
        suruculuk = request.POST.get('suruculuk')
        unvan = request.POST.get('unvan')
        
        # İcarə məlumatları
        baslama = request.POST.get('baslama_tarixi')
        bitis = request.POST.get('bitis_tarixi')
        
        # Validasiya
        if not all([ad, soyad, telefon, email, vesiqe, suruculuk, unvan, baslama, bitis]):
            messages.error(request, 'Bütün sahələri doldurun.')
            return redirect('pages:rent_car', car_id=car_id)
        
        try:
            # Müştəri yarat və ya tap
            customer, created = Customer.objects.get_or_create(
                email=email,
                defaults={
                    'ad': ad,
                    'soyad': soyad,
                    'telefon': telefon,
                    'vesiqe_nomresi': vesiqe,
                    'suruculuk_vesiqesi': suruculuk,
                    'unvan': unvan,
                }
            )
            
            # İcarə yarat
            rental = Rental.objects.create(
                masin=car,
                musteri=customer,
                baslama_tarixi=baslama,
                bitis_tarixi=bitis,
                gunluk_qiymet=car.gunluk_qiymet,
                depozit=car.gunluk_qiymet * 2,
            )
            
            # Maşının statusunu dəyiş
            car.status = 'icarede'
            car.save()
            
            messages.success(request, 'İcarə uğurla tamamlandı!')
            return redirect('pages:rental_success', rental_id=rental.id)
            
        except Exception as e:
            messages.error(request, f'Xəta baş verdi: {str(e)}')
            return redirect('pages:rent_car', car_id=car_id)
    
    context = {
        'car': car,
        'min_date': (timezone.now() + timedelta(days=1)).strftime('%Y-%m-%d'),
        'depozit': car.gunluk_qiymet * 2,  # ADD THIS LINE ✅
    }
    return render(request, 'pages/rent_car.html', context)


def rental_success(request, rental_id):
    """İcarə uğur səhifəsi"""
    rental = get_object_or_404(Rental, id=rental_id)
    
    context = {
        'rental': rental,
    }
    return render(request, 'pages/rental_success.html', context)


def my_rentals(request):
    """Müştərinin icarələri (email ilə)"""
    email = request.GET.get('email', '')
    rentals = []
    
    if email:
        try:
            customer = Customer.objects.get(email=email)
            rentals = customer.rentals.all().order_by('-yaradilma_tarixi')
            
            # Pagination
            paginator = Paginator(rentals, RENTALS_PER_PAGE)
            page_number = request.GET.get('page', 1)
            page_obj = paginator.get_page(page_number)
            
            context = {
                'page_obj': page_obj,
                'email': email,
                'customer': customer,
            }
            return render(request, 'pages/my_rentals.html', context)
        except Customer.DoesNotExist:
            messages.error(request, 'Bu email ilə müştəri tapılmadı.')
    
    return render(request, 'pages/my_rentals.html', {'email': email})


def rental_detail(request, rental_id):
    """İcarə detalları"""
    rental = get_object_or_404(Rental, id=rental_id)
    
    context = {
        'rental': rental,
    }
    return render(request, 'pages/rental_detail.html', context)


def about(request):
    """Haqqında səhifəsi"""
    return render(request, 'pages/about.html')


def contact(request):
    """Əlaqə səhifəsi"""
    if request.method == 'POST':
        ad = request.POST.get('ad')
        email = request.POST.get('email')
        mesaj = request.POST.get('mesaj')
        
        if all([ad, email, mesaj]):
            messages.success(request, 'Mesajınız göndərildi. Tezliklə sizinlə əlaqə saxlayacağıq.')
            return redirect('pages:contact')
        else:
            messages.error(request, 'Bütün sahələri doldurun.')
    
    return render(request, 'pages/contact.html')