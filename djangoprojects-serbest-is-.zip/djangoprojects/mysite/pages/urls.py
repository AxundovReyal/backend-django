from django.urls import path
from . import views

app_name = 'pages'  # Bu ÇOX VACİBDİR!

urlpatterns = [
    # Ana səhifə - bütün maşınlar
    path('', views.car_list, name='car_list'),
    
    # Maşın detalları
    path('car/<int:car_id>/', views.car_detail, name='car_detail'),
    
    # İcarə səhifələri
    path('car/<int:car_id>/rent/', views.rent_car, name='rent_car'),
    path('rental/success/<int:rental_id>/', views.rental_success, name='rental_success'),
    
    # Müştəri icarələri
    path('my-rentals/', views.my_rentals, name='my_rentals'),
    path('rental/<int:rental_id>/', views.rental_detail, name='rental_detail'),
    
    # Haqqında və əlaqə
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
]