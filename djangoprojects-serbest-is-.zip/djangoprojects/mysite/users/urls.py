from django.urls import path,include,re_path
from . import views
from django.contrib import admin

productInfo = {
    "id": "1234",
    "name": "apple",
    "model": "iphone 17",
    "color": "Black"
}

urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about', kwargs=productInfo),
    path('allproducts/', views.get_products),

    
    re_path(r'^product/(?P<id>[0-9]{4})/', views.product_detail, name='product_detail'),
]
