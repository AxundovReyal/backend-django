from django.shortcuts import render
from django.http import HttpResponse

def about(request, **kwargs):
    # kwargs ilə göndərilən məlumatlar
    info = f"Product Info: ID={kwargs.get('id')}, Name={kwargs.get('name')}, Model={kwargs.get('model')}, Color={kwargs.get('color')}"
    return HttpResponse(info)

def get_products(request):
    category = request.GET.get("category")
    if category:
        return HttpResponse(f"All Products in category: {category}")
    return HttpResponse("All Products (no category selected)")

def product_detail(request, id):
    return HttpResponse(f"Product Detail for ID: {id}")

def index(request):
    product_name = request.GET.get('name')
    product_color = request.GET.get('color')
    return HttpResponse(f'{product_name} {product_color}')
    